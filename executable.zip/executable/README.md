This executable created with [Cengine](https://github.com/Mesteri05/CEngine/).

## CEngine (Convert Engine)

This is a *converter* for python to create **exe from py**. CEngine create *automatically* virtualenv and install the packages.

- It's using pyinstaller to create exe. 
- It's better because the executable is smaller (less bytes) and,
- **CEngine** starts a cleaning proccess and
deletes the dist, build, *.spec files/directory when the converting is ended.